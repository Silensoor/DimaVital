package com.example.miftsd;


import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView text = findViewById(R.id.textView);


    }

    public void onClockButton(View view) {
        new GetNewTicket().execute();


    }

    public class GetNewTicket extends AsyncTask<Void, Void, Void> {
        String setText;

        @Override
        protected Void doInBackground(Void... params) {
            SharedPreferences mSharedPref = getPreferences(MODE_PRIVATE);
            AnswerIn1c answer = new AnswerIn1c();
            answer.setGuid(mSharedPref.getString("GUID", ""));
            setText = (GetData.Get(answer));
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
        TextView textView = findViewById(R.id.textView);
        textView.setText(setText);
        }
    }
}
