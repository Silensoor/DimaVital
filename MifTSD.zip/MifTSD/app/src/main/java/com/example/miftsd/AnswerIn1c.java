package com.example.miftsd;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AnswerIn1c {
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("guid")
    @Expose
    private String guid;

    public String getGuid() {
        return guid;
    }

    public String getType() {
        return type;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public void setType(String type) {
        this.type = type;
    }


}
